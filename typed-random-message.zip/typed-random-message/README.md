# Typed Random Message

A Pen created on CodePen.io. Original URL: [https://codepen.io/Boogiesox/pen/KwdqWR](https://codepen.io/Boogiesox/pen/KwdqWR).

This is a very simple javascript function to simulate typing text. To use it, just create  a container with a number of text nodes and a random node will be selected and typed using a realistic typing simulation using randomized key intervals.